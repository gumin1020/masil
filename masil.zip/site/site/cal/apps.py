from django.apps import AppConfig


class CalConfig(AppConfig):
    name = 'cal'
